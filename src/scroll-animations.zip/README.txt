A Pen created at CodePen.io. You can find this one at https://codepen.io/bramus/pen/yikfd.

 Trigger CSS animations on scroll. Detailed explanation can be found at http://www.bram.us/2013/11/20/scroll-animations/