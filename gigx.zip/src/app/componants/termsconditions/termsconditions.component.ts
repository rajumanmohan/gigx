import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-termsconditions',
  templateUrl: './termsconditions.component.html',
  styleUrls: ['./termsconditions.component.scss']
})
export class TermsconditionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scroll(0, 0);

  }

}
